import numpy as np
from . import *    # is this correct?

def SE(sigma, theta):
    """Create a squared exponential kernel

    Args:
        sigma (float) : The standard deviation of the kernel.
        theta (float) : The length scale of the kernel.
        

    Returns:
        squared_exponential (function) : A function of two numpy.ndarrays of floats that computes the squared exponential
        kernel with given standard deviation and length scale.
    """

    def squared_exponential(x1,x2):
        """
        Args:
            x1 : (n x d) array of floats
            x2 : (m x d) array of floats

        Returns:
            (n x m) covariance matrix
        """

        norm_sq = np.square(x1).reshape(-1, 1) + np.square(x2)  - 2 * np.dot(x1.reshape(-1, 1), x2.reshape(1, -1))
        K = sigma**2 * np.exp(- norm_sq / ((theta**2)))
        return K
    
    return squared_exponential