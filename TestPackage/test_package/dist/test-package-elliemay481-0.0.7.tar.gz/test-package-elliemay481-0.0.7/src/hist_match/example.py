import numpy as np

def true_model(x, t):
    f0  = 1
    return f0 * np.exp(x * t)